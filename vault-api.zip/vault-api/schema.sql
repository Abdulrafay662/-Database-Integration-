-- Pillar 1: The Blueprint (Schema & Design)
-- One-to-Many: one user -> many notes

CREATE TABLE IF NOT EXISTS users (
  id         SERIAL PRIMARY KEY,                       -- Primary Key
  name       VARCHAR(100) NOT NULL,                    -- NOT NULL
  email      VARCHAR(255) NOT NULL UNIQUE,             -- UNIQUE
  age        INT NOT NULL CHECK (age >= 18),           -- CHECK
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS notes (
  id         SERIAL PRIMARY KEY,
  user_id    INT NOT NULL
             REFERENCES users(id) ON DELETE CASCADE,   -- Foreign Key
  title      VARCHAR(150) NOT NULL CHECK (length(trim(title)) > 0),
  content    TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_notes_user_id ON notes(user_id);
