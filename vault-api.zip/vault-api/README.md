# Vault API - DecodeLabs Project 3 (Database Integration)

Express + PostgreSQL (native `pg` driver). Schema, full CRUD, constraints, parameterized queries.

## Setup
```bash
npm install
cp .env.example .env          # edit DATABASE_URL if needed
docker compose up -d          # optional: starts Postgres (or use your own)
npm run db:init               # creates tables from schema.sql
npm start
```

## Schema (1 user -> many notes)
- users: id PK, name NOT NULL, email UNIQUE NOT NULL, age CHECK (>= 18), created_at
- notes: id PK, user_id FK -> users(id) ON DELETE CASCADE, title NOT NULL, content, created_at, updated_at

## Endpoints
| CRUD   | HTTP   | Route                 | SQL    |
|--------|--------|-----------------------|--------|
| Create | POST   | /users                | INSERT |
| Read   | GET    | /users, /users/:id    | SELECT |
| Update | PUT/PATCH | /users/:id         | UPDATE |
| Delete | DELETE | /users/:id            | DELETE |
| Create | POST   | /users/:id/notes      | INSERT |
| Read   | GET    | /users/:id/notes, /notes/:id | SELECT |
| Update | PUT    | /notes/:id            | UPDATE |
| Delete | DELETE | /notes/:id            | DELETE |

## Test with curl
```bash
curl -X POST localhost:3000/users -H "Content-Type: application/json" \
  -d '{"name":"Alice","email":"alice@email.com","age":25}'

curl localhost:3000/users
curl -X PATCH localhost:3000/users/1 -H "Content-Type: application/json" -d '{"age":26}'

curl -X POST localhost:3000/users/1/notes -H "Content-Type: application/json" \
  -d '{"title":"First note","content":"Hello vault"}'
curl localhost:3000/users/1/notes

# Constraint checks (should fail cleanly)
curl -X POST localhost:3000/users -H "Content-Type: application/json" \
  -d '{"name":"Bob","email":"alice@email.com","age":30}'     # 409 duplicate email
curl -X POST localhost:3000/users -H "Content-Type: application/json" \
  -d '{"name":"Kid","email":"kid@email.com","age":15}'       # 400 age < 18

# SQL injection attempt - treated as plain data, not logic
curl "localhost:3000/users/1%20OR%201=1"                     # 400 invalid id

curl -X DELETE localhost:3000/users/1                        # notes cascade-deleted
```
