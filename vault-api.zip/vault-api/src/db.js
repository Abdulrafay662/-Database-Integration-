// Pillar 2: The Bridge (Integration & Connection) - native driver `pg`
require('dotenv').config();
const { Pool } = require('pg');

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

pool.on('error', (err) => console.error('Unexpected DB error:', err));

module.exports = pool;
