// Pillar 3: The Action (CRUD & RESTful HTTP)
// Pillar 4: The Shield (parameterized queries + DB constraints + error mapping)
require('dotenv').config();
const express = require('express');
const pool = require('./db');

const app = express();
app.use(express.json());

/* ---------- helpers ---------- */
const isId = (v) => Number.isInteger(Number(v)) && Number(v) > 0;
const bad = (res, msg) => res.status(400).json({ error: msg });
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

function validateUser(b, partial = false) {
  const errs = [];
  if (!partial || b.name !== undefined)
    if (typeof b.name !== 'string' || !b.name.trim()) errs.push('name is required');
  if (!partial || b.email !== undefined)
    if (typeof b.email !== 'string' || !/^\S+@\S+\.\S+$/.test(b.email)) errs.push('valid email is required');
  if (!partial || b.age !== undefined)
    if (!Number.isInteger(b.age) || b.age < 18) errs.push('age must be an integer >= 18');
  return errs;
}

/* ---------- health ---------- */
app.get('/health', wrap(async (_req, res) => {
  await pool.query('SELECT 1');
  res.json({ status: 'ok', db: 'connected' });
}));

/* ================= USERS ================= */

// CREATE  (HTTP POST = SQL INSERT)
app.post('/users', wrap(async (req, res) => {
  const errs = validateUser(req.body);
  if (errs.length) return bad(res, errs.join(', '));
  const { name, email, age } = req.body;
  const { rows } = await pool.query(
    'INSERT INTO users (name, email, age) VALUES ($1, $2, $3) RETURNING *',
    [name.trim(), email.trim().toLowerCase(), age]
  );
  res.status(201).json(rows[0]);
}));

// READ all  (HTTP GET = SQL SELECT)
app.get('/users', wrap(async (_req, res) => {
  const { rows } = await pool.query('SELECT * FROM users ORDER BY id');
  res.json(rows);
}));

// READ one
app.get('/users/:id', wrap(async (req, res) => {
  if (!isId(req.params.id)) return bad(res, 'invalid id');
  const { rows } = await pool.query('SELECT * FROM users WHERE id = $1', [req.params.id]);
  if (!rows.length) return res.status(404).json({ error: 'user not found' });
  res.json(rows[0]);
}));

// UPDATE full  (HTTP PUT = SQL UPDATE)
app.put('/users/:id', wrap(async (req, res) => {
  if (!isId(req.params.id)) return bad(res, 'invalid id');
  const errs = validateUser(req.body);
  if (errs.length) return bad(res, errs.join(', '));
  const { name, email, age } = req.body;
  const { rows } = await pool.query(
    'UPDATE users SET name = $1, email = $2, age = $3 WHERE id = $4 RETURNING *',
    [name.trim(), email.trim().toLowerCase(), age, req.params.id]
  );
  if (!rows.length) return res.status(404).json({ error: 'user not found' });
  res.json(rows[0]);
}));

// UPDATE partial  (HTTP PATCH)
app.patch('/users/:id', wrap(async (req, res) => {
  if (!isId(req.params.id)) return bad(res, 'invalid id');
  const errs = validateUser(req.body, true);
  if (errs.length) return bad(res, errs.join(', '));
  const { name = null, email = null, age = null } = req.body;
  const { rows } = await pool.query(
    `UPDATE users SET
       name  = COALESCE($1, name),
       email = COALESCE($2, email),
       age   = COALESCE($3, age)
     WHERE id = $4 RETURNING *`,
    [name && name.trim(), email && email.trim().toLowerCase(), age, req.params.id]
  );
  if (!rows.length) return res.status(404).json({ error: 'user not found' });
  res.json(rows[0]);
}));

// DELETE  (HTTP DELETE = SQL DELETE) - notes are removed via ON DELETE CASCADE
app.delete('/users/:id', wrap(async (req, res) => {
  if (!isId(req.params.id)) return bad(res, 'invalid id');
  const { rowCount } = await pool.query('DELETE FROM users WHERE id = $1', [req.params.id]);
  if (!rowCount) return res.status(404).json({ error: 'user not found' });
  res.status(204).end();
}));

/* ================= NOTES (child of users) ================= */

// CREATE note for a user
app.post('/users/:id/notes', wrap(async (req, res) => {
  if (!isId(req.params.id)) return bad(res, 'invalid id');
  const { title, content = '' } = req.body;
  if (typeof title !== 'string' || !title.trim()) return bad(res, 'title is required');
  const { rows } = await pool.query(
    'INSERT INTO notes (user_id, title, content) VALUES ($1, $2, $3) RETURNING *',
    [req.params.id, title.trim(), String(content)]
  ); // FK violation (no such user) is mapped to 404 in the error handler
  res.status(201).json(rows[0]);
}));

// READ all notes of a user
app.get('/users/:id/notes', wrap(async (req, res) => {
  if (!isId(req.params.id)) return bad(res, 'invalid id');
  const { rows } = await pool.query(
    'SELECT * FROM notes WHERE user_id = $1 ORDER BY id', [req.params.id]
  );
  res.json(rows);
}));

// READ one note
app.get('/notes/:id', wrap(async (req, res) => {
  if (!isId(req.params.id)) return bad(res, 'invalid id');
  const { rows } = await pool.query('SELECT * FROM notes WHERE id = $1', [req.params.id]);
  if (!rows.length) return res.status(404).json({ error: 'note not found' });
  res.json(rows[0]);
}));

// UPDATE note
app.put('/notes/:id', wrap(async (req, res) => {
  if (!isId(req.params.id)) return bad(res, 'invalid id');
  const { title, content = '' } = req.body;
  if (typeof title !== 'string' || !title.trim()) return bad(res, 'title is required');
  const { rows } = await pool.query(
    'UPDATE notes SET title = $1, content = $2, updated_at = NOW() WHERE id = $3 RETURNING *',
    [title.trim(), String(content), req.params.id]
  );
  if (!rows.length) return res.status(404).json({ error: 'note not found' });
  res.json(rows[0]);
}));

// DELETE note
app.delete('/notes/:id', wrap(async (req, res) => {
  if (!isId(req.params.id)) return bad(res, 'invalid id');
  const { rowCount } = await pool.query('DELETE FROM notes WHERE id = $1', [req.params.id]);
  if (!rowCount) return res.status(404).json({ error: 'note not found' });
  res.status(204).end();
}));

/* ---------- 404 + central error handler ---------- */
app.use((_req, res) => res.status(404).json({ error: 'route not found' }));

app.use((err, _req, res, _next) => {
  // Map PostgreSQL constraint errors to clean HTTP responses
  switch (err.code) {
    case '23505': return res.status(409).json({ error: 'duplicate value violates a UNIQUE constraint' });
    case '23502': return res.status(400).json({ error: 'a required (NOT NULL) field is missing' });
    case '23514': return res.status(400).json({ error: 'value violates a CHECK constraint' });
    case '23503': return res.status(404).json({ error: 'referenced user does not exist' });
    case '22P02': return res.status(400).json({ error: 'invalid input format' });
  }
  console.error(err);
  res.status(500).json({ error: 'internal server error' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Vault API running on http://localhost:${PORT}`));
