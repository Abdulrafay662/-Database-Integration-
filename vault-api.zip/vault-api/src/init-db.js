const fs = require('fs');
const path = require('path');
const pool = require('./db');

(async () => {
  try {
    const sql = fs.readFileSync(path.join(__dirname, '..', 'schema.sql'), 'utf8');
    await pool.query(sql);
    console.log('Schema created successfully.');
  } catch (err) {
    console.error('Database Connection/Schema Error:', err.message);
    process.exitCode = 1;
  } finally {
    await pool.end();
  }
})();
